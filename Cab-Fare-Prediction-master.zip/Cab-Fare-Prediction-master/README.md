# Cab-Fare-Prediction
Data Science project on Cab Fare Prediction, Machine learning algorithms are used to develop a regression model
Problem Statement : The project is about a cab company who has done its pilot project and now they are looking to predict the fare for their future transactional cases. As, nowadays there are number of cab companies like Uber, Ola, Meru Cabs etc. And these cab companies deliver services to lakhs of customers daily. Now it becomes really important to manage their data properly to come up with new business ideas to get best results. In this case, earn most revenues.
So, it becomes really important estimate the fare prices accurately.
